# HonorGoogleDock-LSPosed

Experimental LSPosed module for Honor Launcher 16.0.20.221. It adds a Google-style search bar overlay to the launcher and attempts to hide it when known desktop-edit/page-reorder controls are visible.

## Build
Upload the contents of this folder to a GitHub repository root and run the included GitHub Actions workflow. The APK is produced at `app/build/outputs/apk/debug/app-debug.apk`.

## Install
1. Build and install the new APK (uninstalling the old module APK first is recommended if Android refuses to update it).
2. In LSPosed, enable the module and scope it to the Honor Launcher package `com.hihonor.android.launcher` (verify the actual package name on your device).
3. Force-stop the launcher or reboot.

## Important limitations
- This is still an overlay, not a native insertion into Honor Launcher's Hotseat/Dock. It cannot truly reserve space in the launcher grid.
- The edit-mode auto-hide checks visible text labels, including the reported `拖动页面可改变页面顺序` text. If Honor's edit UI has no readable text or uses different wording, auto-hide may not trigger.
- The module has not been built by GitHub Actions or tested on a device in this environment. Please test and send the LSPosed log if it still overlays controls.
